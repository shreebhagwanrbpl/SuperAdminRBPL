"use client";
import "./district.css"
import { useState, useEffect } from "react";
import { db } from "@/lib/clientDb";
import {
  doc,
  setDoc,
  serverTimestamp,
  writeBatch
} from "@/lib/clientDb";
import { usePathname } from "next/navigation";

export default function Page() {
  const WEBSITE = "centralbiomedicals";
  const [jsonData, setJsonData] = useState([]);
  const [loading, setLoading] = useState(false);
  const [fileName, setFileName] = useState("");

  useEffect(() => {
    const saved = localStorage.getItem("districtJson");

    if (saved) {
      const parsed = JSON.parse(saved);

      setJsonData(parsed.data || []);
      setFileName(parsed.fileName || "");
    }
  }, []);
  // JSON Upload
  const handleFileUpload = async (e) => {
    const file = e.target.files[0];

    if (!file) return;

    setFileName(file.name);

    const text = await file.text();

    try {
      const parsed = JSON.parse(text);

      // check array
      if (!Array.isArray(parsed)) {
        alert("JSON Array Required");
        return;
      }

      // state save
      setJsonData(parsed);

      // localStorage save
      localStorage.setItem(
        "districtJson",
        JSON.stringify({
          data: parsed,
          fileName: file.name,
        })
      );

    } catch (err) {
      console.log(err);
      alert("Invalid JSON");
    }
  };

  // Database Upload
  const uploadToDatabase = async () => {
    try {
      setLoading(true);

      const batch = writeBatch(db);

      jsonData.forEach((item) => {

        const ref = doc(
          db,
          "websites",
          WEBSITE,
          "districts",
          item.slug
        );

        batch.set(ref, {
          district: item.district || "",
          slug: item.slug || "",
          state: item.state || "",
          createdAt: serverTimestamp(),
        });

      });

      await batch.commit();

      alert("Data Uploaded Successfully");

      localStorage.removeItem("districtJson");

    } catch (err) {
      console.log(err);
      alert("Upload Failed");
    } finally {
      setLoading(false);
    }
  };

  const pathname = usePathname();
const pathParts = pathname
  .split("/")
  .filter(Boolean);

  return (
    <div className="districtPage">
      <div className="top-header">

  <div className="page-path">
    {pathParts.map((part, index) => (
      <span key={index}>
        {part.charAt(0).toUpperCase() + part.slice(1)}
        {index !== pathParts.length - 1 && " > "}
      </span>
    ))}
  </div>

  <h1 className="heading">
    District Page Admin
  </h1>

</div>

      <div className="districtContainer">

        {/* HEADER */}
        <div className="headerBox">

          <div> 
            <h1>District JSON Upload</h1>
            <p>
              Upload JSON file and push district data to Database
            </p>
          </div>

          <div className="topButtons">

            <label className="chooseBtn">
              Choose JSON File

              <input
                type="file"
                accept=".json"
                onChange={handleFileUpload}
                hidden
              />
            </label>

            <button
              onClick={uploadToDatabase}
              disabled={loading || jsonData.length === 0}
              className="uploadBtn"
            >
              {loading ? "Uploading..." : "Upload Database"}
            </button>

          </div>

        </div>

        {/* FILE */}
        {fileName && (
          <div className="fileBox">
            📁 {fileName}
          </div>
        )}

        {/* STATS */}
        <div className="statsGrid">

          <div className="card">
            <span>Total Records</span>
            <h2>{jsonData.length}</h2>
          </div>

          <div className="card">
            <span>Collection</span>
            <h2>districts</h2>
          </div>

          <div className="card">
            <span>Status</span>
            <h2 className="green">Ready</h2>
          </div>

        </div>

        {/* TABLE */}
        <div className="tableWrapper">

          <table>

            <thead>
              <tr>
                <th>#</th>
                <th>District</th>
                <th>Slug</th>
                <th>State</th>
              </tr>
            </thead>

            <tbody>

              {jsonData.length > 0 ? (
                jsonData.map((item, index) => (
                  <tr key={index}>

                    <td>{index + 1}</td>

                    <td>
                      <strong>{item.district}</strong>
                    </td>

                    <td>
                      <span className="slug">
                        {item.slug}
                      </span>
                    </td>

                    <td>{item.state}</td>

                  </tr>
                ))
              ) : (
                <tr>
                  <td colSpan="4">

                    <div className="emptyBox">

                      <div className="icon">
                        📂
                      </div>

                      <p>
                        No JSON File Uploaded
                      </p>

                    </div>

                  </td>
                </tr>
              )}

            </tbody>

          </table>

        </div>

      </div>


    </div>
  );
}